﻿

namespace GameFramework.SkillSystem
{
    public class SkillManagement
    {
        public static void Create()
        {

        }
    }
}
