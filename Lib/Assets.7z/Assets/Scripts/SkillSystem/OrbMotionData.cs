﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace GameFramework.SkillSystem
{
    public abstract class OrbMotionData
    {
        public uint id;
        public string name;

        
    }
}