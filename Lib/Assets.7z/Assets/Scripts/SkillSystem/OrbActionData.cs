﻿
namespace GameFramework.SkillSystem
{
    public abstract class OrbActionData
    {
        public uint id;
        public string name;
    }
}