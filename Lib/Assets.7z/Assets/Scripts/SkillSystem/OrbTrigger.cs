﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GameFramework.SkillSystem
{
    public class OrbTrigger : IOrbTrigger
    {
        public virtual void Tick(float p_ElapsedSec)
        {
            
        }

        public virtual void Trigger()
        {
            
        }
    }
}
