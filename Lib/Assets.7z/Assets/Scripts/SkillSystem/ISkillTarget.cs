﻿

namespace GameFramework.SkillSystem
{
    /// <summary>
    /// 技能目标
    /// </summary>
    public interface ISkillTarget
    {
    }
}
