﻿

namespace GameFramework.SkillSystem
{
    /// <summary>
    /// 法球释放者
    /// </summary>
    public interface IOrbCaster
    {
    }
}
